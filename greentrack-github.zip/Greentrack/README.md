# GreenTrack

**Award winner — Fundação EDP "Escola da Energia" university competition (2026)**

GreenTrack is a mobile app that helps households understand their electricity consumption. Users upload an electricity bill (PDF or photo); the app extracts the relevant data with OCR and AI, turns it into clear insights, and suggests concrete saving measures tailored to their profile.

Built by a team of four students at ISEC — Polytechnic of Coimbra, in partnership with Fundação EDP. 95% of users surveyed said the app could change their energy habits.

📰 Press: [Diário de Coimbra — "Alunos do ISEC premiados pela Escola de Energia"](https://www.diariocoimbra.pt/2026/05/08/alunos-do-isec-premiados-pela-escola-de-energia/)

## Architecture

```
React Native app (Expo)  ──►  Spring Boot API (JWT, PostgreSQL)  ──►  AI service (Flask)
                                                                      ├─ PyMuPDF: PDF text extraction
                                                                      ├─ Tesseract: OCR for photos
                                                                      └─ OpenAI API: analysis & saving tips
```

| Folder | Stack |
|---|---|
| `frontend/` | React Native, Expo, TypeScript |
| `backend/` | Java 17, Spring Boot, Spring Security + JWT, JPA, PostgreSQL |
| `greentrackAIAGent/` | Python, Flask, PyMuPDF, Tesseract OCR, OpenAI API |

## Running locally

Prerequisites: Java 17+, Node.js 18+, Python 3.8+, PostgreSQL, Tesseract.

Each service reads its configuration from environment variables — see the `.env.example` file in each folder.

**AI service**
```bash
cd greentrackAIAGent
pip install -r requirements.txt
export OPENAI_API_KEY=sk-...
python ai_agent.py            # http://localhost:5000
```

**Backend**
```bash
cd backend
export DB_PASSWORD=... JWT_SECRET=...
./mvnw spring-boot:run        # http://localhost:8080
```

**App**
```bash
cd frontend
npm install
EXPO_PUBLIC_API_URL=http://<your-LAN-IP>:8080 npx expo start
```

## Roadmap

- Support for gas and water bills
- Integration with smart devices for real-time monitoring
